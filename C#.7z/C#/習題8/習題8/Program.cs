﻿using System;

namespace test
{
    class Program
    {
        static void Main(string[] args)
        {
            int[,] arr = new int[2, 3];
            long sum = 0;
            Random rn = new Random();
            long num = 0;
            for (int i = 0; i < 2; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    arr[i, j] = rn.Next();
                    Console.Write("arr[{0}, {1}] = {2} \t", i, j, arr[i,j] );
                    sum += arr[i,j];
                }
                Console.WriteLine("Sum = {0}" , sum);
                sum = 0;
            }

        }
    }
}
