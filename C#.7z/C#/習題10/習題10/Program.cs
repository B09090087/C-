﻿using System;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace test
{
    class Program
    {
        static void Main(string[] args)
        {
            DateTime Dtime;
            string add;
            while (true)
            {
                Console.Write("請輸入一個日期字串: ");
                add = Console.ReadLine();

                if(DateTime.TryParse(add, out Dtime))
                {
                    Console.WriteLine($"{Dtime:yyyy-MM-dd}");
                }
                else
                {
                    Console.WriteLine("輸入字串不能轉換為日期");
                }
            }
        }
    }
}