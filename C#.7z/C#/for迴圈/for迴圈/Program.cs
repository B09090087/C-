﻿// for迴圈

int[] nums = { 12, 456, 78, 56, 89 , 1 , 23 , 56 ,47 , 77};


for(int i = 0; i < nums.Length; i++)
{
    System.Console.WriteLine(nums[i]);
}