﻿using System;

namespace test
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("請輸入數組長度: ");
            byte[] nums = new byte[int.Parse(Console.ReadLine())];
            Random rn = new Random();
            rn.NextBytes(nums);
            Console.Write("隨機數填充後的數組為: ");
            for (int i = 0; i < nums.Length; i++)
            {
                Console.Write(nums[i] + " ");
            }
            Console.ReadKey();
        }
    }
}