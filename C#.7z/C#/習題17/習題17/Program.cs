﻿using System;

namespace test
{
    class Program
    {
        static void Main(string[] args)
        {
            string input;
            int count = 0;
            List<int> list = new List<int>();
            Console.WriteLine("請輸入一個字串: ");
            input = Console.ReadLine();

            for (int i = 0; i < input.Length; i++)
            {
                if (char.IsDigit(input[i]))
                {
                    count++;
                    list.Add(i);
                }
            }
            Console.WriteLine("數字出現的次數為: {0}", count);
            Console.WriteLine("所處的位置分別為:");
            foreach (int i in list)
            {
                Console.Write(i+" ");
            }
        }
    }
}