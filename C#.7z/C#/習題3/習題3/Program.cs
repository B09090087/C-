﻿using System;

namespace test
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] a = new int[10];
            string b;
            double sum;
            double num = 0;
            
            for (int i = 0; i < 10 ; i++)
            {

                Console.Write("請輸入數組的第{0}個元素:",(i+1).ToString());
                b = Console.ReadLine();
                if (string.IsNullOrEmpty(b))
                {
                    Console.WriteLine("不可輸入為空");
                    i--;
                }
                else 
                {
                    try
                    {
                        a[i] = int.Parse(b);
                    }
                    catch
                    {
                        Console.WriteLine("非法輸入");
                        i--;
                        continue;
                    }
                    
                }
                num += a[i];
            }
            sum = num/10;
            Console.WriteLine(sum.ToString("0.0000"));

        }
    }
}