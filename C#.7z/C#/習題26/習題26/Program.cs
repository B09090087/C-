﻿using System;

namespace test
{
    class Program
    {
        static void Main(string[] args)
        {
            string input;
            while (true)
            {
                Console.Write("請輸入一個字串: ");
                input = Console.ReadLine();
                if (input == "") 
                    break;
                char[] cr = input.ToCharArray();
                Console.Write("刪除字母後的字串為: ");
                for (int i = 0;i < cr.Length; i++)
                {
                    if (char.IsDigit(cr[i]) || char.IsPunctuation(cr[i]))
                    {
                        Console.Write(cr[i] + " ");
                    }
                }
                Console.WriteLine();
            }
        }
    }
}