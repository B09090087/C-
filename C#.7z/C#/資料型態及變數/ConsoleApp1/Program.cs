﻿System.Console.WriteLine("嗨，你們好!");

//字串 string "石頭"
//整數 int 21
//字元 char 'M'
//浮點數 double 169.8
//布林值 bool  true false

string name = "石頭";
int age = 21;
char sex = 'M';
double height = 169.8;
bool is_male = true;

System.Console.WriteLine("我是石頭");
System.Console.WriteLine("今年22歲");
System.Console.WriteLine("身高169.8公分");
System.Console.WriteLine("石頭討厭自己169.8公分");

System.Console.WriteLine("我是" + name);
System.Console.WriteLine("今年" + age + "歲");
System.Console.WriteLine("身高"+ height +"公分");
System.Console.WriteLine(name + "討厭自己" + height + "公分");