﻿// class、object 類別 物件


Person person1 = new Person();
person1.height = 169.8;
person1.age = 22;
person1.name = "石頭";

Person person2 = new Person();
person2.height = 160.8;
person2.age = 22;
person2.name = "小白";

System.Console.WriteLine(person1.age);
System.Console.WriteLine(person1.name);