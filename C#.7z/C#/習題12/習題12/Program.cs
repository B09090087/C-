﻿using System;

namespace test
{
    class Program
    {
        static void Main(string[] args)
        {
            Random rand = new Random();
            int num;

            while (true)
            {
                num = rand.Next(100, 1000);
                int hundred = num / 100;
                int ten = (num / 10 ) % 10;
                int one = num % 10;
                int ans = hundred + ten + one;
                Console.WriteLine("隨機生成的3位整數是{0}, 其數值合為{1}", num, ans);
                Console.ReadKey();
            }

        }
    }
}