﻿using System;

namespace test
{
    class Program
    {
        static void Main(string[] args)
        {
            int num;
            string input;
            while (true)
            {
                Console.Write("請輸入數字: ");
                input = Console.ReadLine();
                if (int.TryParse(input, out int ans)) 
                {
                    if (ans > 0)
                    {
                        Console.WriteLine("輸入的數字為{0}, Positive", ans);
                    }
                    else if (ans < 0)
                    {
                        Console.WriteLine("輸入的數字為{0}, Negative", ans);
                    }
                    else
                    {
                        Console.WriteLine("輸入的數字為{0}, Zero", ans);
                    }
                }
                else
                {
                    Console.WriteLine("輸入的不為數字");
                }
                Console.ReadKey();
            }
        }
    }
}