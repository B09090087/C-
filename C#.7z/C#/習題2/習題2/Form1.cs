namespace 習題2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Random rn = new Random();
            List<int> list = new List<int>();
            listBox1.Items.Clear();

            for (int i = 0; list.Count < 6 ; i++)
            {
                int num = rn.Next(1,50);
                bool check = list.Contains(num);
                if (check == false) 
                {
                    list.Add(num);
                }
            }
            list.Sort();
            foreach (int num in list) 
            {
                listBox1.Items.Add(num);
            }

        }
    }
}
