﻿using System;

namespace test
{
    class Program
    {
        static void Main(string[] args)
        {
            string a;


            while (true)
            {
                Console.Write("請輸入一個字符串 : ");
                a = Console.ReadLine();
                if (a == "")
                    break;
                char[] chars = a.ToCharArray();
                Array.Reverse(chars);
                Console.Write("逆敘後的字符串為 : ");
                foreach (char c in chars)
                {
                    Console.Write(c);
                }
                Console.WriteLine();
            }
        }
    }
}