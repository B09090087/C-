﻿using System;

namespace test
{
    class Program
    {
        static void Main(string[] args)
        {
            Random rand = new Random();
            byte[] num = new byte[10];
            rand.NextBytes(num);
            Array.Sort(num);
            Array.Reverse(num);
            for (int i = 0; i < num.Length; i++)
            {
               Console.WriteLine("arr[{0}]={1}", i , num[i]);
            }
        }
    }
}