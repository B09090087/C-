﻿using System;

namespace test
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] arr = { 5, 1, 23, 31, 56, 28, 98, 24, 76, 82 };
            List<int> list = arr.ToList();
            Random rand = new Random();

            for (int i = 0; i < 5; i++)
            {
                int ans;
                ans = list[rand.Next(0, arr.Length-1)];
                Console.Write(ans + " ");
            }

        }
    }
}