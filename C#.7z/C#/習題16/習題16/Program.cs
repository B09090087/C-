﻿using System;

namespace test
{
    class Program
    {
        static void Main(string[] args)
        {
            string input;
            while (true)
            {
                Console.Write("請輸入一個字串: ");
                input = Console.ReadLine();
                Console.WriteLine("字串長度為: {0}", input.Length);
                if (input.Contains('A')||input.Contains('a'))
                {
                    Console.WriteLine("該字串中存在a or A字符");
                }
                else
                {
                    string add = input.Insert(0, "A");
                    Console.WriteLine("在首位插入A後的字串為: {0}", add);
                }
            }
        }
    }
}