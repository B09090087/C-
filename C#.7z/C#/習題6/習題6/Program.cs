﻿using System;

namespace test
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] ints = new int[10];
            string temp;
            for (int i = 0; i < 10; i++)
            {
                Console.Write("請輸入第{0}個元素，一共10個元素: ", (i + 1).ToString());
                temp = Console.ReadLine();
                while (true)
                {
                    try
                    {
                        ints[i] = int.Parse(temp);
                        break;
                    }
                    catch
                    {
                        Console.Write("第{0}個元素輸入錯誤，請重新輸入: ", (i + 1).ToString());
                        temp = Console.ReadLine();
                    }
                }
            }
            foreach (int num in ints)
            {
                Console.Write(num + " ");
            }
        }
    }
}