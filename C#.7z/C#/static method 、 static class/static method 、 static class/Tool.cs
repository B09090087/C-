﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace static_method___static_class
{
    static class Tool
    {
        public static void SayHi()
        {
            Console.WriteLine("Hello");
        }
    }
}
