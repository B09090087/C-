﻿// static method 、 static class
using static_method___static_class;
using System;



Tool.SayHi();
Console.WriteLine(Math.Sqrt(36));