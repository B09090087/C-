﻿using System;
using System.Text;

namespace test
{
    class Program
    {
        static void Main(string[] args)
        {
            string input;
            
            while (true)
            {
                Console.WriteLine("請輸入一個字串: ");
                input = Console.ReadLine();
                int count = 0, i = 0;

                
                while (input.Contains("ab"))
                {
                    if ((input[i] == 'a' && input[i + 1] == 'b') && i < input.Length
                        ) 
                    {
                        input = input.Remove(i, 2);
                        input = input.Insert(i, "cd");
                        i += 2;
                        count++;
                    }
                }

                if (count != 0)
                {
                    Console.WriteLine("將ab替換成cd之後的字串為: {0}", input);
                    Console.WriteLine("共替換了{0}次", count);
                }
                else
                    Console.WriteLine("原字串中沒有ab字符");

            }
        }
    }
}