﻿using System;

namespace test
{
    class Program
    {
        static void Main(string[] args)
        {
            int num;
            Random rnd = new Random();
            num = rnd.Next(60 , 101);

            if (num >= 60 && num <= 75) 
            {
                Console.WriteLine("生成隨機數值為{0}, OK!", num);
            }
            else if (num >75 && num <= 90)
            {
                Console.WriteLine("生成隨機數值為{0}, good!", num);
            }
            else
            {
                Console.WriteLine("生成隨機數值為{0}, excellent!", num);
            }
            Console.ReadKey();
        }
    }
}