﻿using System;

namespace test
{
    class Program
    {
        static void Main(string[] args)
        {
            string a;

            while (true)
            {
                Console.Write("請輸入一個字符串: ");
                a = Console.ReadLine();
                if(a == "")
                    break;
                char[] chars = a.ToCharArray();

                int count = 0;

                for(int i=0; i<chars.Length; i++)
                {
                    if (char.IsPunctuation(chars[i]))
                    {
                        chars[i] = ' ';
                    }
                }

                a = new string(chars);

                Console.WriteLine(a);

                string[] strings = a.Split(" ");
                for (int i = 0; i < strings.Length; i++)
                {
                    if (strings[i] != "") 
                        count++;
                }
                
                Console.WriteLine("該字串一共有" + count + "個單詞");

                Console.Write("逆序後的字串為: ");

                for (int i = strings.Length - 1; i >= 0; i--) 
                {
                    if (strings[i] != "")
                        Console.Write(strings[i]+" ");
                }
                Console.WriteLine();
                
            }
        }
    }
}

