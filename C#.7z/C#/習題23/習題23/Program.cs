﻿using Microsoft.VisualBasic;
using System;

namespace test
{
    class Program
    {
        static void Main(string[] args)
        {
            string input;
            while (true)
            {
                Console.WriteLine("請輸入一個字串: ");
                input = Console.ReadLine();
                int count = 0;
                if (input == "")
                    break;
                string[] sArray = input.Split('/');
                foreach(var s in sArray)
                {
                    count++;
                }
                Console.WriteLine("數組的個數為: {0}", count);

                Console.Write("逆序後的數組為: ");
                for (int i = sArray.Length - 1; i >= 0; i--)
                {
                    Console.Write(sArray[i] + " ");
                }

            }

        }
    }
}