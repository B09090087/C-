﻿// 取得用戶輸入

System.Console.Write("請輸入你的名字 : ");
string name = System.Console.ReadLine();
System.Console.Write("請輸入你的年紀 : ");
string age = System.Console.ReadLine();
System.Console.WriteLine("你好啊，" + name + "。" + "你今年" + age + "歲");