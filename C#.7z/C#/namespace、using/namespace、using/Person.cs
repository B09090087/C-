﻿namespace Animal
{
    namespace qq
    {
        class Person
        {
            public double height;
            public int age;
            public string name;
        }
    }
  

}


