﻿using System;

namespace test
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("請輸入x(0-100): ");
            int x = Convert.ToInt32(Console.ReadLine());
            Console.Write("請輸入y(0-30): ");
            int y = Convert.ToInt32(Console.ReadLine());
            double z = x * 0.7 + y;
            Console.WriteLine("z = {0}*0.7+{1} = {2}", x , y, z.ToString("#.00"));



        }
    }
}