﻿// inheritance 繼承
using ConsoleApp1;
using System;

Student student1 = new Student("小白", 9, "新豐國小");

student1.PrintName();
student1.PrintAge();
student1.PrintSchool();

Console.WriteLine(student1.school);