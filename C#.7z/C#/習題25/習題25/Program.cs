﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace test
{
    class Program
    {
        static void Main(string[] args)
        {
            string input;
            while (true)
            {
                Console.Write("請輸入一個字串: ");
                input = Console.ReadLine();
                int sum = 0;
                if (input == "")
                    break;
                char[] cr = input.ToCharArray();
                Console.Write("字串中的數字字符為: ");
                for (int i = 0; i < cr.Length; i++)
                {
                    if (char.IsDigit(cr[i]))
                    {
                        sum++;
                        Console.Write(cr[i]+" ");

                    }
                }
                Console.WriteLine("一共有{0}個數字字符", sum);
               
            }
        }
    }
}