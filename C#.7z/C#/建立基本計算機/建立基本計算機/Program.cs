﻿// 建立基本計算機

System.Console.Write("請輸入第一個數 : ");
double num1 = System.Convert.ToDouble(System.Console.ReadLine());
System.Console.Write("請輸入第二個數 : ");
double num2 = System.Convert.ToDouble(System.Console.ReadLine());
System.Console.WriteLine(num1+num2);