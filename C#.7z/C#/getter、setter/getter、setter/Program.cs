﻿// getter、setter
using System;
using ConsoleApp1;

Video video1 = new Video("哇哈哈哈哈", "小白", "你好");
Video video2 = new Video("真的讚", "小黑", "教育");


Console.WriteLine(video1.Type);