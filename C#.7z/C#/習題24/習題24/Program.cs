﻿using System;

namespace test
{
    class Program
    {
        static void Main(string[] args)
        {
            Random rand = new Random();
            int[] num = new int[10];
            int sum = 0;
            Console.Write("數組為: ");
            for (int i = 0; i < 10; i++)
            {
                num[i] = rand.Next(0,11);
                sum += num[i];
                Console.Write(num[i]+" ");
            }
            Console.WriteLine();
            Console.WriteLine("數組最大值為: {0}", num.Max());
            double avg = (double)sum / 10;
            Console.WriteLine("數組平均值為: {0}", avg);

        }
    }
}