﻿using System;

namespace test
{
    class Program
    {
        static void Main(string[] args)
        {
            string add;
            
            while (true) 
            {
                Console.Write("請輸入一個字串: ");
                add = Console.ReadLine();
                //char[] chars = add.ToCharArray();
                bool check = true;
                if (add.Length != 5)
                {
                    Console.WriteLine("字符長度不是5!");
                }
                else
                {
                    /*
                    for (int i = 0; i < chars.Length; i++)
                    {
                        check = char.IsUpper(chars[i]);
                    }
                    */
                    foreach (char c in add) 
                    {
                        check = char.IsUpper(c);
                    }
                    if (check) 
                    {
                        Console.WriteLine("輸入字母為5個大寫字母!");
                        break;
                    }
                    else
                    {
                        Console.WriteLine("輸入字符不是5個大寫字母!");
                    }
                }
            }
            Console.WriteLine("請按任一鍵繼續....");
            Console.ReadKey();
        }
    }
}