namespace 習題1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox3.Clear();
            int even;
            int add = int.Parse(textBox1.Text);

            for (even = 1; even <= add; even++)
            {
                if (even % 2 == 0)
                {
                    textBox3.AppendText(even.ToString());
                    textBox3.AppendText("\r\n");
                }

            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox3.Clear();
            int factor, add;
            add = int.Parse(textBox2.Text);

            for (factor = 1; factor <= add; factor++)
            {
                if (add % factor == 0)
                {
                    textBox3.AppendText(factor.ToString());
                    textBox3.AppendText("\r\n");
                }
            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox3.Clear();
            int num1, num2;

            for (num1 = 1; num1 < 10; num1++)
            {
                for (num2 = 1; num2 < 10; num2++)
                {
                    int total = num1 * num2;
                    textBox3.AppendText(num1 + "*" + num2 + "=" + total);
                    textBox3.AppendText(" ");
                }
                textBox3.AppendText("\r\n");
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            textBox3.Clear();
            string triangle = "*";

            for (int i = 0; i <= 10; i++)
            {
                for(int j = 0; j <= i; j++)
                {
                    textBox3.AppendText(triangle);
                    
                }
                textBox3.AppendText("\r\n");
            }

        }
    }
}
