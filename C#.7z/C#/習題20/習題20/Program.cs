﻿using System;

namespace test
{
    class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                try
                {
                    Console.WriteLine("請輸入一個字串: ");
                    double input = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine("轉換後的字串為: ");
                    //Console.WriteLine(input.ToString("###,###.0000\n"));
                    Console.WriteLine(string.Format("{0:N4}",input)+"\n");
                }
                catch 
                {
                    Console.WriteLine("轉換後的字串為: ");
                    Console.WriteLine("轉換失敗\n");
                }
                
            }
        }
    }
}