﻿using System;

namespace test
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("請輸入3個整數: ");
            string input;
            string[] strings = new string[3];
            input = Console.ReadLine();
            strings = input.Split(' ');
            Array.Sort(strings);
            Console.Write("從小到大排序後為: ");
            foreach (string s in strings)
            {
                Console.Write(s +" ");
            }
            
            Console.ReadKey();
            

        }
    }
}