﻿using System;

namespace test
{
    class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                Console.Write("請輸入0-10之內的數字: ");
                int input = int.Parse(Console.ReadLine());
                if (input > 10)
                    continue;
                try
                {
                    double num = Math.Pow(input, 3);
                    Console.WriteLine(num.ToString("000"));
                }
                catch 
                {
                    Console.WriteLine("請按規範輸入!");
                }
            }
        }
    }
}