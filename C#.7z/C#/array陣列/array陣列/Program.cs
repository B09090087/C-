﻿// array陣列

int[] scores = { 50, 60, 70, 30, 20 };
string[] phones = new string[10];



scores[1] = 90;
System.Console.WriteLine(scores[0]);
System.Console.WriteLine(scores[1]);
System.Console.WriteLine(scores[2]);
System.Console.WriteLine(scores[3]);
System.Console.WriteLine(scores[4]);

phones[0] = "0123456789";
phones[1] = "0888888888";

System.Console.WriteLine(phones[0]);
System.Console.WriteLine(phones[1]);