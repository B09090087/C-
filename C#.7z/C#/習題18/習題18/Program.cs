﻿using System;
using System.Text.RegularExpressions;

namespace test
{
    class Program
    {
        static void Main(string[] args)
        {
            string input;
            Console.WriteLine("請輸入一個字串: ");
            input = Console.ReadLine();
            string result = Regex.Replace(input, @"\d", "");
            Console.WriteLine("去除數字後的字串為: \n{0}", result);
        }
    }
}